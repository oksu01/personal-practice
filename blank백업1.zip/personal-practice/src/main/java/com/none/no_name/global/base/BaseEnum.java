package com.none.no_name.global.base;

public interface BaseEnum {
	String getName();
	String getDescription();
}
