package com.none.no_name.domain.memberMusic.repository;

import com.none.no_name.domain.memberMusic.entity.MemberMusic;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberMusicRepository extends JpaRepository<MemberMusic, Long> {
}
