package com.none.no_name.auth.oauth.profile;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class MemberProfile {

	private String email;
}
