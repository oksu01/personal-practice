package com.none.no_name;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoNameApplicationTests {

	@Test
	void contextLoads() {
	}

}
